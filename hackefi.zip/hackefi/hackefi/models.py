from dataclasses import dataclass, field


@dataclass
class HardwareInfo:
    cpu: str = "未知"
    gpu: list[str] = field(default_factory=list)
    motherboard: str = "未知"
    network: list[str] = field(default_factory=list)
    disks: list[str] = field(default_factory=list)
    boot_mode: str = "未知"
    secure_boot: str = "未知"

    def as_text(self) -> str:
        def lines(title, values):
            return f"{title}:\n" + "\n".join(f"  - {x}" for x in values) if values else f"{title}: 未发现"
        return "\n\n".join([
            f"CPU: {self.cpu}", f"主板: {self.motherboard}",
            lines("显卡", self.gpu), lines("网卡", self.network), lines("磁盘", self.disks),
            f"启动模式: {self.boot_mode}\n安全启动: {self.secure_boot}",
        ])
