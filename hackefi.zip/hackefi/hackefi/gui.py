import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
from .detector import detect_hardware
from .generator import generate
from .rules import assess


class App(ttk.Frame):
    def __init__(self, root):
        super().__init__(root, padding=14)
        root.title("黑苹果 EFI 助手 · 候选配置生成器")
        root.minsize(780, 600)
        self.pack(fill="both", expand=True)
        self.hardware = None
        self.assessment = None
        ttk.Label(self, text="黑苹果 EFI 助手", font=("Microsoft YaHei UI", 18, "bold")).pack(anchor="w")
        ttk.Label(self, text="仅生成可审阅的候选骨架；请勿把它视为可直接启动的万能 EFI。", foreground="#9b3a00").pack(anchor="w", pady=(2, 10))
        bar = ttk.Frame(self); bar.pack(fill="x")
        ttk.Button(bar, text="检测本机硬件", command=self.scan).pack(side="left")
        self.create_button = ttk.Button(bar, text="生成候选 EFI", command=self.create, state="disabled")
        self.create_button.pack(side="left", padx=8)
        self.download_files = tk.BooleanVar(value=True)
        ttk.Checkbutton(bar, text="联网下载 OpenCore 和基础 kext", variable=self.download_files).pack(side="left")
        self.text = scrolledtext.ScrolledText(self, wrap="word", font=("Microsoft YaHei UI", 10))
        self.text.pack(fill="both", expand=True, pady=10)
        self.show("点击“检测本机硬件”开始。检测不会修改系统。\n\n提示：网络、声卡与显卡的名称未必足以确定精确芯片型号，报告会列出需要人工核对的项目。")

    def show(self, value):
        self.text.configure(state="normal"); self.text.delete("1.0", "end"); self.text.insert("1.0", value); self.text.configure(state="disabled")

    def scan(self):
        self.show("正在读取 Windows 硬件信息，请稍候…")
        self.update_idletasks()
        self.hardware = detect_hardware(); self.assessment = assess(self.hardware)
        a = self.assessment
        content = "检测结果\n========\n" + self.hardware.as_text() + "\n\n推荐\n========\n" + f"建议起点：{a.macos}\n候选 SMBIOS：{a.smbios}\n{a.summary}\n\n风险与待核对项\n========\n" + "\n".join(f"• {x}" for x in a.warnings or ["暂无明显规则命中，但仍需人工验证。"]) + "\n\n下一步\n========\n" + "\n".join(f"• {x}" for x in a.actions)
        self.show(content); self.create_button.configure(state="normal")

    def create(self):
        directory = filedialog.askdirectory(title="选择一个空文件夹保存候选 EFI")
        if not directory: return
        try:
            result = generate(directory, self.hardware, self.assessment, self.download_files.get())
            messagebox.showinfo("已生成", f"候选 EFI 已生成到：\n{result}\n\n{'已下载基础文件；' if self.download_files.get() else ''}请先阅读硬件审查报告，再按 Dortania 指南核验。")
        except FileExistsError as error:
            messagebox.showwarning("未生成", str(error))
        except OSError as error:
            messagebox.showerror("写入失败", f"无法写入目标文件夹：\n{error}")
        except RuntimeError as error:
            messagebox.showerror("未生成完整 EFI", f"下载或解压官方发布包失败：\n{error}\n\n请检查网络后重试，或取消联网下载以只生成候选骨架。")


def run():
    root = tk.Tk()
    try: ttk.Style().theme_use("vista")
    except tk.TclError: pass
    App(root); root.mainloop()
