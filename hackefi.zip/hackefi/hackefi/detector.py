import json
import platform
import subprocess
from .models import HardwareInfo


def _powershell(script: str):
    """返回 PowerShell JSON；兼容中文 Windows 的控制台编码。"""
    try:
        # 不使用 text=True：Windows PowerShell 在某些地区会用本地代码页写管道，
        # 由 subprocess 按 UTF-8 解码会让 reader 线程提前退出。
        utf8_script = (
            "$utf8 = [System.Text.UTF8Encoding]::new($false); "
            "[Console]::OutputEncoding = $utf8; $OutputEncoding = $utf8; " + script
        )
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", utf8_script],
            capture_output=True, timeout=20, check=True,
        )
        raw = result.stdout or b""
        for encoding in ("utf-8-sig", "utf-8", "mbcs", "gbk"):
            try:
                return json.loads(raw.decode(encoding))
            except (UnicodeDecodeError, json.JSONDecodeError):
                continue
        return None
    except (OSError, subprocess.SubprocessError):
        return None


def _items(value):
    if not value:
        return []
    return value if isinstance(value, list) else [value]


def detect_hardware() -> HardwareInfo:
    fallback = HardwareInfo(cpu=platform.processor() or "未知（无法读取）")
    if platform.system() != "Windows":
        fallback.boot_mode = "非 Windows 环境，未检测"
        return fallback
    script = r'''
    $o = [ordered]@{
      cpu=(Get-CimInstance Win32_Processor | ForEach-Object { "$($_.Name)（$($_.NumberOfCores) 核）" })
      gpu=(Get-CimInstance Win32_VideoController | ForEach-Object Name)
      board=(Get-CimInstance Win32_BaseBoard | ForEach-Object { "$($_.Manufacturer) $($_.Product)" })
      network=(Get-CimInstance Win32_NetworkAdapter | Where-Object { $_.PhysicalAdapter -and $_.NetEnabled } | ForEach-Object Name)
      disks=(Get-CimInstance Win32_DiskDrive | ForEach-Object { "$($_.Model)（$([math]::Round($_.Size/1GB)) GB）" })
      boot=if (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State') {'UEFI'} else {'Legacy 或无法确认'}
      secure=(Get-ItemPropertyValue -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction SilentlyContinue)
    }; $o | ConvertTo-Json -Compress
    '''
    data = _powershell(script)
    if not data:
        fallback.boot_mode = "无法读取（请以 BIOS 实际设置为准）"
        return fallback
    secure = data.get("secure")
    return HardwareInfo(
        cpu="；".join(_items(data.get("cpu"))) or fallback.cpu,
        gpu=_items(data.get("gpu")), motherboard="；".join(_items(data.get("board"))) or "未知",
        network=_items(data.get("network")), disks=_items(data.get("disks")),
        boot_mode=data.get("boot") or "未知", secure_boot={True: "已启用", False: "已关闭"}.get(secure, "未知"),
    )
