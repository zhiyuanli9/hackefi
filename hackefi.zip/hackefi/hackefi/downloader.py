"""从项目官方 GitHub Release 下载 OpenCore 与基础 kext。

不固定版本号，以 GitHub 的 latest release API 获取发布包；下载失败不会留下“完整 EFI”的假象。
"""
import json
from io import BytesIO
from pathlib import Path
from shutil import copyfileobj
from urllib.request import Request, urlopen
from zipfile import ZipFile


RELEASES = {
    "OpenCore": ("acidanthera/OpenCorePkg", "OpenCore-", "X64/EFI/OC/"),
    "Lilu.kext": ("acidanthera/Lilu", "Lilu-", None),
    "VirtualSMC.kext": ("acidanthera/VirtualSMC", "VirtualSMC-", None),
    "WhateverGreen.kext": ("acidanthera/WhateverGreen", "WhateverGreen-", None),
    "AppleALC.kext": ("acidanthera/AppleALC", "AppleALC-", None),
}


def _latest_asset(repo: str, prefix: str) -> bytes:
    api = f"https://api.github.com/repos/{repo}/releases/latest"
    request = Request(api, headers={"Accept": "application/vnd.github+json", "User-Agent": "HackEFI-Candidate"})
    with urlopen(request, timeout=45) as response:
        release = json.load(response)
    asset = next((item for item in release.get("assets", []) if item["name"].startswith(prefix) and item["name"].endswith(".zip")), None)
    if not asset:
        raise RuntimeError(f"{repo} 的最新发布中未找到 {prefix}*.zip")
    request = Request(asset["browser_download_url"], headers={"User-Agent": "HackEFI-Candidate"})
    with urlopen(request, timeout=120) as response:
        return response.read()


def _copy_member_tree(archive: ZipFile, prefix: str, destination: Path):
    found = False
    for member in archive.infolist():
        if member.is_dir() or not member.filename.startswith(prefix):
            continue
        relative = Path(member.filename[len(prefix):])
        target = destination / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(member) as source, target.open("wb") as output:
            copyfileobj(source, output)
        found = True
    if not found:
        raise RuntimeError(f"发布包不含预期目录：{prefix}")


def _copy_kext(archive: ZipFile, kext_name: str, destination: Path):
    marker = f"/{kext_name}/"
    matches = [item for item in archive.infolist() if marker in f"/{item.filename}" and not item.is_dir()]
    if not matches:
        raise RuntimeError(f"发布包不含 {kext_name}")
    # 发行包有时包含 Debug/Release 两份。优先 Release，若版本布局改变则选第一个完整包。
    release_matches = [item for item in matches if "/Release/" in item.filename]
    selected = release_matches or matches
    start = selected[0].filename.index(kext_name)
    for item in selected:
        index = item.filename.find(kext_name)
        if index != start:
            continue
        target = destination / item.filename[index:]
        target.parent.mkdir(parents=True, exist_ok=True)
        with archive.open(item) as source, target.open("wb") as output:
            copyfileobj(source, output)


def download_base_files(oc_dir: Path, kext_names: list[str]) -> list[str]:
    """下载官方发布包并写入 OC 目录；成功时返回实际写入的 kext 名称。"""
    repo, prefix, oc_prefix = RELEASES["OpenCore"]
    with ZipFile(BytesIO(_latest_asset(repo, prefix))) as archive:
        _copy_member_tree(archive, oc_prefix, oc_dir)
    installed = []
    for kext_name in kext_names:
        if kext_name not in RELEASES:
            continue
        repo, prefix, _ = RELEASES[kext_name]
        with ZipFile(BytesIO(_latest_asset(repo, prefix))) as archive:
            _copy_kext(archive, kext_name, oc_dir / "Kexts")
        installed.append(kext_name)
    if not (oc_dir / "OpenCore.efi").exists():
        raise RuntimeError("OpenCore 发布包中未找到 OpenCore.efi，已停止生成。")
    return installed
