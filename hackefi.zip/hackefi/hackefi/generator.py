import plistlib
import shutil
from pathlib import Path
from .models import HardwareInfo
from .rules import Assessment
from .downloader import download_base_files


def config_template(assessment: Assessment, installed_kexts=None):
    installed_kexts = installed_kexts or []
    kernel_add = [{"Arch": "Any", "BundlePath": name, "Comment": "自动下载的基础 kext；仍需核验版本", "Enabled": True, "ExecutablePath": f"Contents/MacOS/{name[:-5]}", "MaxKernel": "", "MinKernel": "", "PlistPath": "Contents/Info.plist"} for name in installed_kexts]
    return {"ACPI": {"Add": [], "Delete": [], "Patch": [], "Quirks": {}}, "Booter": {"Quirks": {}},
            "DeviceProperties": {"Add": {}, "Delete": {}}, "Kernel": {"Add": kernel_add, "Patch": [], "Quirks": {}},
            "Misc": {"Boot": {"ShowPicker": True, "Timeout": 5}, "Security": {"ScanPolicy": 0}, "Tools": []},
            "NVRAM": {"Add": {}, "Delete": {}, "LegacyEnable": False}, "PlatformInfo": {"Generic": {"SystemProductName": assessment.smbios, "SystemSerialNumber": "请用 GenSMBIOS 生成", "MLB": "请用 GenSMBIOS 生成", "SystemUUID": "请用 GenSMBIOS 生成"}, "UpdateSMBIOSMode": "Create"},
            "UEFI": {"APFS": {"EnableJumpstart": True}, "Drivers": ["OpenRuntime.efi"] if installed_kexts else [], "Quirks": {}}}


def generate(destination: str, hw: HardwareInfo, assessment: Assessment, download_files=False) -> Path:
    root = Path(destination) / "HackEFI-Candidate"
    if root.exists():
        raise FileExistsError(f"目标已存在：{root}；请选择空目录或移走旧结果。")
    for name in ("ACPI", "Drivers", "Kexts", "Resources", "Tools"):
        (root / "EFI" / "OC" / name).mkdir(parents=True, exist_ok=True)
        (root / "EFI" / "OC" / name / "请将所需文件放在这里.txt").write_text("请严格按 Dortania 指南添加文件，并在 config.plist 中登记。\n", encoding="utf-8")
    oc_dir = root / "EFI" / "OC"
    installed_kexts = []
    try:
        if download_files:
            installed_kexts = download_base_files(oc_dir, assessment.kexts)
        with (oc_dir / "config.plist").open("wb") as f:
            plistlib.dump(config_template(assessment, installed_kexts), f, sort_keys=False)
    except Exception:
        # 联网模式不能留下一个看似已完成、实则缺文件的目录。
        shutil.rmtree(root, ignore_errors=True)
        raise
    report = "# 硬件审查报告（候选 EFI）\n\n## 检测到的硬件\n\n```\n" + hw.as_text() + "\n```\n\n## 推荐\n\n- 推荐起点：" + assessment.macos + "\n- 候选 SMBIOS：" + assessment.smbios + "\n- " + assessment.summary + "\n\n## 风险与未知项\n\n" + "\n".join(f"- {x}" for x in assessment.warnings or ["仍需逐项核对精确硬件型号。"]) + "\n\n## 必做事项\n\n" + "\n".join(f"- {x}" for x in assessment.actions) + "\n"
    (root / "硬件审查报告.md").write_text(report, encoding="utf-8")
    state = "已从各项目官方 GitHub Release 下载 OpenCore 与基础 kext，并登记到 config.plist。" if download_files else "候选 EFI 不含 OpenCore、驱动或 kext。请按 Dortania 指南自行下载并验证。"
    followup = state + "\n建议核对的 kext：\n" + "\n".join(assessment.kexts) + "\n"
    (root / "后续操作.txt").write_text(followup, encoding="utf-8")
    return root
