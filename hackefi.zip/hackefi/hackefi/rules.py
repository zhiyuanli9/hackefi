from dataclasses import dataclass
from .models import HardwareInfo


@dataclass
class Assessment:
    macos: str
    summary: str
    warnings: list[str]
    actions: list[str]
    kexts: list[str]
    smbios: str = "请按平台选择 SMBIOS"


# 规则刻意使用容易由 Windows 设备名称识别的关键词。添加新型号时请保留
# “关键词 -> 保守结论”的写法，并以 Dortania/实际测试为依据更新说明。
GPU_RULES = (
    (("uhd 630", "hd 630", "uhd 620", "iris plus"), "Intel 核显（UHD/HD 6xx 或 Iris Plus）", "macOS Monterey（12）或 Ventura（13）", "iMac19,1"),
    (("uhd 730", "uhd 750", "uhd 770"), "Intel 11/12 代桌面核显", "macOS Ventura（13）", "iMac20,2"),
    (("rx 560", "rx 570", "rx 580", "rx 590"), "AMD Radeon RX 5xx（Polaris）", "macOS Monterey（12）或 Ventura（13）", "iMacPro1,1"),
    (("vega 56", "vega 64", "radeon vii"), "AMD Vega / Radeon VII", "macOS Monterey（12）或 Ventura（13）", "iMacPro1,1"),
    (("rx 5500", "rx 5600", "rx 5700"), "AMD Radeon RX 5x00（Navi）", "macOS Ventura（13）或 Sonoma（14）", "iMacPro1,1"),
    (("rx 6600", "rx 6700", "rx 6800", "rx 6900", "rx 6950"), "AMD Radeon RX 6x00（RDNA 2）", "macOS Ventura（13）或 Sonoma（14）", "MacPro7,1"),
)

WIFI_RULES = (
    (("bcm94360", "bcm943602", "bcm94352"), "检测到常见博通 BCM943xx 无线网卡：请核对精确芯片和对应 macOS 版本；可能需要额外补丁。", []),
    (("intel wi-fi", "intel(r) wi-fi", "wireless-ac", "wi-fi 6"), "检测到 Intel 无线网卡：macOS 无原生驱动，通常需要 OpenIntelWireless 的 itlwm/AirportItlwm；隔空投送与接力不能承诺可用。", ["itlwm.kext 或 AirportItlwm.kext（按系统版本二选一）"]),
    (("realtek",), "检测到 Realtek 无线网卡：兼容性取决于精确型号，通常建议更换为经验证的博通或使用 USB 网卡。", []),
)


def assess(hw: HardwareInfo) -> Assessment:
    joined_gpu = " ".join(hw.gpu).lower()
    joined_cpu = hw.cpu.lower()
    warnings, actions = [], ["在 BIOS 中启用 UEFI、关闭 CSM，并确认 Secure Boot 已关闭。", "制作 USB 启动盘并先从 USB 测试；不要直接替换现有 EFI。"]
    macos = "macOS Ventura（13）或 Monterey（12）"
    smbios = "iMac19,1（仅为 Intel Coffee Lake 台式机候选）"
    summary = "以 Intel 平台为前提的保守建议；具体版本须由显卡与 Wi‑Fi 芯片决定。"
    known_gpu = False
    for keywords, name, version, proposed_smbios in GPU_RULES:
        if any(keyword in joined_gpu for keyword in keywords):
            known_gpu = True
            macos, smbios = version, proposed_smbios
            summary = f"识别为 {name}；此版本与 SMBIOS 均是候选，仍须按 CPU 平台和显示输出核验。"
            break
    if "amd" in joined_gpu or "radeon" in joined_gpu:
        warnings.append("检测到 AMD 独显：请核对精确架构；部分新卡、笔记本混合显卡与部分型号不受支持。")
    is_kepler = any(x in joined_gpu for x in ("gtx 6", "gtx 7", "quadro k"))
    if any(x in joined_gpu for x in ("nvidia", "geforce", "rtx", "gtx 16")) and not is_kepler:
        warnings.append("检测到 NVIDIA 显卡：现代 macOS 对多数 NVIDIA（尤其 RTX/GTX 16 系）没有驱动；通常需要禁用它并使用受支持的核显/AMD 显卡。")
        macos = "macOS Monterey（12）或更早版本，且仍需核对显卡"
    elif is_kepler:
        warnings.append("检测到可能的 NVIDIA Kepler 显卡：通常只建议最高 macOS Big Sur（11）；请按精确型号确认。")
        macos = "macOS Big Sur（11）"
    elif any(x in joined_gpu for x in ("rx 7600", "rx 7700", "rx 7800", "rx 7900", "radeon 7")):
        warnings.append("检测到可能的 AMD RDNA 3/RX 7x00 显卡：不应假定 macOS 原生支持，须寻找精确型号的验证资料。")
    elif hw.gpu and not known_gpu:
        warnings.append("显卡名称未命中已验证型号表；请确认精确 GPU 架构、PCI ID 与对应 macOS 的驱动支持。")
    if "amd" in joined_cpu or "ryzen" in joined_cpu:
        warnings.append("检测到 AMD/Ryzen CPU：需要 AMD 专用 OpenCore 内核补丁，部分软件与虚拟化不兼容；本工具不自动写入补丁。")
    if not hw.gpu:
        warnings.append("未读到显卡型号，无法给出可靠的版本建议。")
    if hw.boot_mode != "UEFI":
        warnings.append("未确认 UEFI 启动。OpenCore 需要 UEFI；请在 BIOS 中核验。")
    if hw.secure_boot == "已启用":
        warnings.append("Secure Boot 当前已启用，OpenCore 启动前通常须在 BIOS 中关闭。")
    for adapter in hw.network:
        adapter_lower = adapter.lower()
        for keywords, warning, needed_kexts in WIFI_RULES:
            if any(keyword in adapter_lower for keyword in keywords):
                warnings.append(warning)
                actions.append(f"核对无线网卡“{adapter}”的精确芯片/PCI ID。")
                for kext in needed_kexts:
                    if kext not in actions:
                        actions.append(f"如确认适用，添加 {kext}。")
                break
    actions += ["用 Hackintool/Windows 设备管理器确认网卡与声卡的精确 PCI ID。", "按 Dortania 对应 CPU 平台章节选择 ACPI、kext 与 SMBIOS。", "完成 USB 映射、声卡 layout-id、睡眠与网络测试。"]
    kexts = ["Lilu.kext", "VirtualSMC.kext", "WhateverGreen.kext", "AppleALC.kext"]
    if any("Intel 无线" in warning for warning in warnings):
        kexts.append("itlwm.kext 或 AirportItlwm.kext（按系统版本二选一）")
    return Assessment(macos, summary, warnings, actions, kexts, smbios)
