from hackefi.gui import run


if __name__ == "__main__":
    run()
