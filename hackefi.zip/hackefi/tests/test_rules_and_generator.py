import plistlib
import tempfile
import unittest
from pathlib import Path
from hackefi.generator import generate
from hackefi.models import HardwareInfo
from hackefi.rules import assess


class CandidateTests(unittest.TestCase):
    def test_nvidia_is_flagged(self):
        result = assess(HardwareInfo(cpu="Intel Core i7", gpu=["NVIDIA GeForce RTX 3060"], boot_mode="UEFI"))
        self.assertTrue(any("NVIDIA" in item for item in result.warnings))

    def test_rx_6800_gets_specific_candidate(self):
        result = assess(HardwareInfo(cpu="Intel Core i7", gpu=["AMD Radeon RX 6800"], boot_mode="UEFI"))
        self.assertIn("Sonoma", result.macos)
        self.assertEqual(result.smbios, "MacPro7,1")

    def test_intel_wifi_gets_kext_hint(self):
        result = assess(HardwareInfo(network=["Intel(R) Wi-Fi 6 AX200"]))
        self.assertTrue(any("itlwm" in item for item in result.kexts))

    def test_creates_editable_candidate(self):
        hardware = HardwareInfo(cpu="Intel", gpu=["Intel UHD"], boot_mode="UEFI")
        with tempfile.TemporaryDirectory() as temp:
            root = generate(temp, hardware, assess(hardware))
            config = root / "EFI" / "OC" / "config.plist"
            self.assertTrue((root / "硬件审查报告.md").exists())
            with config.open("rb") as file:
                data = plistlib.load(file)
            self.assertTrue(data["Misc"]["Boot"]["ShowPicker"])
            self.assertIn("PlatformInfo", data)

    def test_config_lists_downloaded_kexts(self):
        from hackefi.generator import config_template
        config = config_template(assess(HardwareInfo()), ["Lilu.kext", "VirtualSMC.kext"])
        self.assertEqual(config["UEFI"]["Drivers"], ["OpenRuntime.efi"])
        self.assertEqual(config["Kernel"]["Add"][0]["BundlePath"], "Lilu.kext")

    def test_refuses_existing_result(self):
        with tempfile.TemporaryDirectory() as temp:
            hardware = HardwareInfo()
            generate(temp, hardware, assess(hardware))
            with self.assertRaises(FileExistsError):
                generate(temp, hardware, assess(hardware))
