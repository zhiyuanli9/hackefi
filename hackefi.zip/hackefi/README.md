# 黑苹果 EFI 助手（候选配置生成器）

一个 Windows 优先的中文 Python 图形化工具：读取电脑的 CPU、显卡、主板、网卡、磁盘与启动模式，依据可审阅的规则推荐 macOS，并生成 **候选** OpenCore EFI 骨架。

> 重要：这不是“万能一键 EFI”。固件设置、USB 映射、声卡布局、无线网卡精确型号、显示输出及睡眠等都必须人工核验。请先用 USB 启动盘测试，保留现有系统备份；不要覆盖正使用的 EFI 分区。

## 运行

Windows PowerShell：

```powershell
cd "C:\Users\zhiyu\Documents\Codex\2026-10-10\referenced-chatgpt-conversation-this-is-an"
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe main.py
```

`tkinter` 随官方 Windows Python 一般已附带。若提示缺失，请重新安装 Python 并勾选 Tcl/Tk。

如果你曾运行旧版后看到 `UnicodeDecodeError`，请使用本项目当前的 `hackefi/detector.py` 替换旧文件（新版已兼容中文 Windows 的 PowerShell 输出编码）。

## 测试

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

## 生成内容与下一步

点击“生成候选 EFI”后选择一个**空文件夹**。默认会从各项目官方 GitHub Release 下载 OpenCore、Lilu、VirtualSMC、WhateverGreen、AppleALC，写入 `EFI/OC` 并登记基础 kext 和 `OpenRuntime.efi`；关闭勾选项则只生成骨架。下载或解压失败会删除不完整的候选目录。

生成目录包含：

- `EFI/OC/OpenCore.efi`、`Drivers/OpenRuntime.efi` 与基础 kext（联网模式）；
- `EFI/OC/config.plist`：已登记基础 kext 的可编辑候选配置；
- `EFI/OC/ACPI`、`Drivers`、`Kexts`、`Resources`、`Tools`：空目录及说明；
- `硬件审查报告.md`：结论、未知项及手动待办；
- `后续操作.txt`：建议下载的 OpenCore 与 kext（不会自动下载或伪装带有驱动）。

请从 [Dortania OpenCore Install Guide](https://dortania.github.io/OpenCore-Install-Guide/) 按报告建议下载与配置 OpenCore、驱动和 kext，再用 ProperTree 或 OpenCore Configurator 审核 `config.plist`。机型识别（SMBIOS）不自动生成序列号，务必使用 GenSMBIOS 自行生成唯一值。

## 规则维护

规则集中在 `hackefi/rules.py`。它刻意采用保守结论：遇到未知硬件会提示人工确认，不会把推测当作兼容。欢迎按硬件实测提交扩展。
